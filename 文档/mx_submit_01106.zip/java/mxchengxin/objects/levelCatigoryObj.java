package com.san.mxchengxin.objects;

public class levelCatigoryObj {
	private String levelId;  // ID
	private String levelName; //NAME
	private String howmanyPeople; // 多少人
	
	
	public String getLevelId() {
		return levelId;
	}
	public void setLevelId(String levelId) {
		this.levelId = levelId;
	}
	public String getLevelName() {
		return levelName;
	}
	public void setLevelName(String levelName) {
		this.levelName = levelName;
	}
	public String getHowmanyPeople() {
		return howmanyPeople;
	}
	public void setHowmanyPeople(String howmanyPeople) {
		this.howmanyPeople = howmanyPeople;
	}
	
	
}
