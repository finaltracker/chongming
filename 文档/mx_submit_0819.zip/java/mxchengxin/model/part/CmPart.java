package com.san.mxchengxin.model.part;

/**
 * CmPart entity. @author MyEclipse Persistence Tools
 */
public class CmPart extends AbstractCmPart implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public CmPart() {
	}

	/** full constructor */
	public CmPart(String partName) {
		super(partName);
	}

}
