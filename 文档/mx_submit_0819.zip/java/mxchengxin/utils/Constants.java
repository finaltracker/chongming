package com.san.mxchengxin.utils;

public class Constants {
	public static Short ADD_ACTION = 1;
	public static Short MODIFY_ACTION = 2;
	public static Short UPDATE_ACTION = 3;

}
